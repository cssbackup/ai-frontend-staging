export { default } from "./GalleryTwo";
