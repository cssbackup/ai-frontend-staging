export { default } from "./GalleryOne";
