import Image from "next/image";
import { Source_Serif_4 } from "next/font/google";
import type { CSSProperties } from "react";
import {
  ArrowRight,
  BarChart3,
  Bell,
  Calendar,
  CheckCircle2,
  ExternalLink,
  Folder,
  Globe,
  Globe2,
  Home,
  LayoutDashboard,
  LayoutTemplate,
  Plus,
  Settings,
  Sparkles,
  User,
  Users,
  Zap,
} from "lucide-react";
import Button from "../ui/Button";
import type { getOnboardingDraftSummary } from "@/lib/onboardingDraft";
import { getHeroStartLabel } from "./DraftResumeModal";

const minutesSerif = Source_Serif_4({
  subsets: ["latin"],
  style: "italic",
  weight: "700",
  display: "swap",
});

const minutesHighlight = `${minutesSerif.className} relative inline-block bg-lime-300 px-[0.22em] py-[0.04em] align-baseline text-[1.02em] font-bold italic leading-[0.95] tracking-[-0.03em] text-black`;

type HeroSectionProps = {
  onStart: () => void;
  draftSummary?: ReturnType<typeof getOnboardingDraftSummary>;
};

const gridSize = "clamp(74px, 10.6vw, 152px)";
const backgroundStyle: CSSProperties = {
  backgroundColor: "#2d5bf1",
  backgroundImage: [
    "linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px)",
    "linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)",
    "radial-gradient(ellipse at 60% 110%, rgba(105, 208, 218, 0.65), transparent 75%)",
    "linear-gradient(120deg, #2855ed, #497cf4)",
  ].join(", "),
  backgroundSize: `${gridSize} ${gridSize}, ${gridSize} ${gridSize}, 100% 100%, 100% 100%`,
  backgroundRepeat: "repeat, repeat, no-repeat, no-repeat",
  backgroundPosition: "center, center, center, center",
};

function MinutesSparkle({ className = "" }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={`pointer-events-none absolute ${className}`}
    >
      <Image
        src="/minutes-sparkle.png"
        alt=""
        width={68}
        height={102}
        className="h-full w-full object-contain"
      />
    </span>
  );
}

const mobilePills = [
  { icon: Zap, label: "No Coding Needed" },
  { icon: LayoutTemplate, label: "Beautiful Templates" },
  { icon: Users, label: "Human Support" },
] as const;

const previewNav = [
  { icon: Home, label: "Dashboard", active: true },
  { icon: Folder, label: "My Websites", active: false },
  { icon: LayoutTemplate, label: "Templates", active: false },
  { icon: Globe, label: "Domain", active: false },
  { icon: BarChart3, label: "Analytics", active: false },
  { icon: Settings, label: "Settings", active: false },
] as const;

const recentSites = [
  { title: "Good Food", image: "/haelli.png" },
  { title: "Stronger Every Day", image: "/blackbay.png" },
  { title: "Transform Your Space", image: "/shaye.png" },
] as const;

function MobileHeroPreview() {
  return (
    <div className="relative w-full overflow-hidden" style={{ containerType: "inline-size" }}>
      <div className="mx-auto w-[700px] origin-top" style={{ zoom: "calc(100cqi / 700px)" }}>
        <div className="mb-4 flex items-center justify-center gap-2.5">
          {mobilePills.map(({ icon: Icon, label }) => (
            <span
              key={label}
              className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[13px] font-medium text-[#1e2a4a] shadow-[0_10px_24px_rgba(15,40,140,.16)]"
            >
              <Icon size={15} className="text-[#3b6cf6]" aria-hidden />
              {label}
            </span>
          ))}
        </div>

        <div className="rounded-[28px] bg-[#1a1d27] p-2.5 shadow-[0_30px_60px_rgba(8,28,110,.32)]">
          <div className="grid grid-cols-[1fr_auto_1fr] items-center px-3 py-2 text-white/80">
            <div className="flex gap-1.5">
              <span className="size-2.5 rounded-full bg-[#ff5f57]" />
              <span className="size-2.5 rounded-full bg-[#febc2e]" />
              <span className="size-2.5 rounded-full bg-[#28c840]" />
            </div>
            <div className="flex h-7 w-[220px] items-center justify-center rounded-full bg-[#2c303b] text-[11px] text-white/80">
              app.lestow.com
            </div>
            <div className="flex items-center justify-end gap-2.5 text-white/70">
              <ExternalLink size={14} aria-hidden />
              <Plus size={15} aria-hidden />
            </div>
          </div>

          <div className="overflow-hidden rounded-[18px] bg-[#f4f6fb] text-[#172033]">
            <div className="grid grid-cols-[158px_minmax(0,1fr)]">
              <aside className="border-r border-black/5 bg-white px-3 py-3.5">
                <div className="mb-3 flex items-center gap-1.5 px-1">
                  <Image src="/lestow-mark.svg" alt="" width={16} height={16} className="size-4" />
                  <span className="text-[13px] font-semibold">Lestow</span>
                </div>
                <nav className="space-y-0.5">
                  {previewNav.map(({ icon: Icon, label, active }) => (
                    <div
                      key={label}
                      className={`flex items-center gap-2 rounded-lg px-2 py-1.5 text-[11px] ${active ? "bg-[#eef3ff] font-medium text-[#2f5cf6]" : "text-[#667085]"
                        }`}
                    >
                      <Icon size={13} aria-hidden />
                      <span>{label}</span>
                    </div>
                  ))}
                </nav>
              </aside>

              <div className="min-w-0 px-3.5 py-3">
                <div className="mb-2 flex items-center justify-end gap-2">
                  <Bell size={14} className="text-[#98a2b3]" aria-hidden />
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-white py-1 pl-1 pr-2.5 text-[11px] text-[#344054] shadow-sm">
                    <span className="relative size-5 overflow-hidden rounded-full bg-[#dbe4ff]">
                      <Image src="/blackbay.png" alt="" fill className="object-cover" sizes="20px" />
                    </span>
                    Alex Carter
                  </span>
                </div>

                <div className="grid grid-cols-[minmax(0,1fr)_158px] items-start gap-3">
                  <div>
                    <p className="text-[11px] text-[#667085]">
                      Welcome back, Alex <span aria-hidden>👋</span>
                    </p>
                    <p className="mt-0.5 text-[20px] font-semibold leading-[1.15] tracking-[-0.03em] text-[#101828]">
                      Your website
                      <br />
                      is almost ready.
                    </p>
                    <p className="mt-1 max-w-[28ch] text-[11px] leading-snug text-[#667085]">
                      Create, customize, and publish with AI — in minutes.
                    </p>
                    <div className="mt-2.5 flex items-center gap-2">
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#2f5cf6] px-3 py-1.5 text-[11px] font-medium text-white">
                        <Plus size={12} aria-hidden />
                        Create Website
                      </span>
                      <span className="rounded-full bg-white px-3 py-1.5 text-[11px] text-[#344054] shadow-sm">
                        View Templates
                      </span>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-[#e8eeff] p-3 text-[11px] leading-snug text-[#31508f]">
                    <Sparkles size={14} className="mb-1.5 text-[#2f5cf6]" aria-hidden />
                    Turn your ideas into a professional website with AI.
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-3 gap-2">
                  <div className="rounded-xl bg-[#eef2ff] p-2.5">
                    <div className="flex items-start justify-between">
                      <p className="text-[18px] font-semibold leading-none text-[#101828]">3</p>
                      <Calendar size={14} className="text-[#7a8cff]" aria-hidden />
                    </div>
                    <p className="mt-1 text-[10px] text-[#667085]">Websites</p>
                    <p className="mt-2 text-[10px] font-medium text-[#2f5cf6]">View all →</p>
                  </div>
                  <div className="rounded-xl bg-[#e7f8ee] p-2.5">
                    <p className="text-[18px] font-semibold leading-none text-[#101828]">12.4K</p>
                    <div className="mt-1 flex items-center justify-between gap-1">
                      <p className="text-[10px] text-[#667085]">Total Visitors</p>
                      <p className="text-[10px] font-semibold text-[#12b76a]">↑ 24%</p>
                    </div>
                    <p className="mt-2 text-[9px] text-[#98a2b3]">Last 30 days</p>
                  </div>
                  <div className="rounded-xl bg-[#e7f8ee] p-2.5">
                    <div className="flex items-start justify-between">
                      <p className="text-[18px] font-semibold leading-none text-[#101828]">89%</p>
                      <BarChart3 size={14} className="text-[#12b76a]" aria-hidden />
                    </div>
                    <div className="mt-1 flex items-center justify-between gap-1">
                      <p className="text-[10px] text-[#667085]">Uptime</p>
                      <p className="text-[10px] font-semibold text-[#12b76a]">↑ 2%</p>
                    </div>
                    <p className="mt-2 text-[9px] text-[#98a2b3]">Last 30 days</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <p className="text-[12px] font-medium text-[#101828]">Recent Websites</p>
                  <p className="text-[11px] font-medium text-[#2f5cf6]">View All →</p>
                </div>
                <div className="mt-1.5 grid grid-cols-3 gap-2">
                  {recentSites.map((site) => (
                    <div key={site.title} className="relative h-[104px] overflow-hidden rounded-xl">
                      <Image src={site.image} alt="" fill className="object-cover" sizes="180px" />
                      <span className="absolute right-1.5 top-1.5 inline-flex items-center gap-1 rounded-full bg-[#22c55e] px-1.5 py-0.5 text-[8px] font-medium text-white">
                        <span className="size-1 rounded-full bg-white" />
                        Live
                      </span>
                      <p className="absolute inset-x-0 bottom-12 px-2 text-[10px] font-medium leading-tight text-white drop-shadow-[0_1px_2px_rgba(0,0,0,.7)]">
                        {site.title}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const statuses = [
  {
    icon: LayoutDashboard,
    text: "Pages structured",
    className: "-left-4 top-[34%] lg:-left-28",
  },
  {
    icon: Sparkles,
    text: "Brand system applied",
    className: "-right-4 top-[24%] lg:-right-32",
  },
  {
    icon: Globe2,
    text: "Ready to publish",
    className: "right-[4%] bottom-[12%] lg:-right-24",
  },
];

export default function HeroSection({
  onStart,
  draftSummary = null,
}: HeroSectionProps) {
  return (
    <section
      data-hero-scroll
      className="relative h-[100dvh] overflow-hidden text-white xl:h-[190vh] xl:min-h-[1250px] xl:overflow-visible"
      style={backgroundStyle}
    >
      <div className="relative flex h-full min-h-0 flex-col overflow-hidden px-4 pt-[76px] sm:px-6 md:px-8 xl:sticky xl:top-0 xl:block xl:h-screen xl:min-h-[740px] xl:overflow-hidden xl:px-8 xl:pb-0 xl:pt-[116px]">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0"
          style={backgroundStyle}
        />

        <div className="relative z-10 flex min-h-0 flex-1 flex-col items-center pb-0 xl:contents xl:h-full xl:flex-none xl:justify-center xl:gap-9 xl:pb-16 xl:pt-20">
          <div className="flex min-h-0 w-full flex-1 flex-col items-center justify-center xl:contents">
            <div
              data-hero-copy
              className="relative z-20 mx-auto w-full max-w-[1500px] shrink-0 text-center"
            >
              <div data-hero-text>
                <h1 className="text-[clamp(4rem,11.4vw,5rem)] font-extrabold not-italic text-center leading-[0.96] tracking-[-.045em] text-white xl:hidden">
                  <span className="block overflow-hidden">
                    <span data-hero-line className="block">
                      Build Your
                    </span>
                  </span>
                  <span className="block overflow-hidden pt-0.5">
                    <span data-hero-line className="block">
                      Website in
                    </span>
                  </span>
                  <span className="block overflow-hidden pb-1 pt-2">
                    <span data-hero-line className="block">
                      <span className={`${minutesHighlight} whitespace-nowrap rounded-[0.14em] !px-[0.28em] !py-[0.06em]`}>
                        10 Minutes
                      </span>
                    </span>
                  </span>
                </h1>
                <h1 className="hidden text-[clamp(3rem,6.5vw,6.2rem)] font-semibold not-italic leading-[.92] tracking-[-.035em] text-white xl:block">
                  <span className="block overflow-hidden pb-2">
                    <span data-hero-line className="block">
                      Build Your
                    </span>
                  </span>
                  <span className="block overflow-hidden pb-3 pt-3">
                    <span data-hero-line className="block whitespace-nowrap">
                      Website in{" "}
                      <span className={`${minutesHighlight} rounded-md`}>
                        10 Minutes
                        <MinutesSparkle className="left-[calc(100%+6px)] top-1/2 h-16 w-11 -translate-y-1/2 lg:h-[4.5rem] lg:w-12" />
                      </span>
                    </span>
                  </span>
                </h1>
                <p
                  data-hero-fade
                  className="mx-auto mt-2 max-w-[32ch] !font-light text-[clamp(12px,1.8dvh,16px)] leading-[1.35] tracking-[-.02em] text-white/90 sm:max-w-[34ch] xl:mt-0 xl:max-w-3xl xl:text-[22px] xl:leading-8"
                  style={{ fontWeight: 300 }}
                >
                  {/* Create a professional website in minutes with AI. Generate
                stunning layouts, engaging content, and customize every detail to
                match your brand. */}
                  Build a beautiful, professional website with AI in minutes.
                </p>
              </div>

              <Button
                type="button"
                onClick={onStart}
                variant="dark"
                className="group relative z-30 mx-auto mt-3 mb-0 flex h-[clamp(44px,6.2dvh,52px)] w-full max-w-[320px] items-center justify-center gap-3 bg-black px-4 text-[15px] font-medium text-white opacity-100 shadow-[0_18px_40px_rgba(4,17,74,.28)] [clip-path:polygon(18px_0,100%_0,100%_100%,0_100%,0_18px)] transition duration-300 hover:-translate-y-1 hover:bg-black hover:shadow-[0_24px_50px_rgba(4,17,74,.38)] md:mt-4 md:h-[52px] md:max-w-[420px] md:text-base xl:mt-3 xl:h-14 xl:max-w-[420px]"
              >
                {getHeroStartLabel(draftSummary)}{" "}
                <ArrowRight
                  size={19}
                  aria-hidden
                  className="transition group-hover:translate-x-1"
                />
              </Button>

              <div className="mt-8 hidden flex-wrap items-center justify-center gap-2.5 sm:mt-5 sm:gap-3 xl:flex">
                <span className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[13px] font-medium text-[#0b1b4a] shadow-[0_8px_22px_rgba(4,17,74,.14)] sm:px-5 sm:text-sm">
                  <Sparkles size={15} className="text-[#2d5bf1]" aria-hidden />
                  AI Powered
                </span>
                <span className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-[13px] font-medium text-[#0b1b4a] shadow-[0_8px_22px_rgba(4,17,74,.14)] sm:px-5 sm:text-sm">
                  <User size={15} className="text-[#2d5bf1]" aria-hidden />
                  Human Support
                </span>
              </div>
            </div>
          </div>

          <div className="relative z-10 mt-[2dvh] h-[clamp(200px,30dvh,420px)] w-full max-w-[920px] shrink-0 overflow-hidden max-xl:!static max-xl:!top-auto max-xl:!translate-x-0 xl:absolute xl:left-1/2 xl:top-[420px] xl:mt-0 xl:h-auto xl:max-h-none xl:w-[min(88vw,1480px)] xl:max-w-none xl:shrink xl:-translate-x-1/2 xl:overflow-visible">
            <div
              data-hero-device
              className="relative origin-top will-change-transform"
            >


              <div className="absolute -inset-3 rounded-[42%] bg-cyan-100/20 blur-[22px] xl:-inset-16 xl:blur-[65px]" />
              <div className="hidden xl:block absolute -inset-7 rounded-[2.6rem] border border-white/15" />
              <div className="hidden xl:block absolute -inset-3 rounded-[2.25rem] border border-cyan-100/25" />

              <div className="relative w-full overflow-hidden xl:hidden">
                <MobileHeroPreview />
              </div>

              <div className="relative hidden overflow-hidden rounded-[2rem] border border-white/60 bg-[#07111e] p-4 shadow-[0_55px_120px_rgba(5,24,111,.6),0_0_0_1px_rgba(255,255,255,.12)] xl:block">
                <div
                  data-dashboard-shine
                  className="pointer-events-none absolute -left-1/2 top-0 z-20 h-full w-1/3 -skew-x-12 bg-gradient-to-r from-transparent via-white/18 to-transparent"
                />
                <div
                  aria-hidden="true"
                  className="flex h-10 items-center justify-between px-3 text-white/85"
                >
                  <div className="flex gap-1.5">
                    <span className="size-2 rounded-full bg-white/40" />
                    <span className="size-2 rounded-full bg-white/40" />
                    <span className="size-2 rounded-full bg-[#b9ff66]" />
                  </div>
                  <span className="text-[8px] font-semibold uppercase tracking-[.18em]">
                    Lestow command center
                  </span>
                  <span className="rounded-md bg-[#b9ff66] px-2.5 py-1 text-[8px] font-semibold text-[#07111e]">
                    Live
                  </span>
                </div>
                <div className="relative aspect-[16/10] overflow-hidden rounded-[1.25rem] bg-white">
                  <Image
                    src="/lestow-dashboard.png"
                    alt="Lestow AI website builder dashboard"
                    fill
                    quality={80}
                    sizes="1080px"
                    className="object-cover object-top"
                    priority={false}
                    loading="lazy"
                  />
                  <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-black/5" />
                </div>
              </div>

              <div
                data-dashboard-status
                className="absolute -top-[74px] left-1/2 hidden -translate-x-1/2 translate-y-10 scale-75 items-center gap-3 whitespace-nowrap rounded-full border border-white/20 bg-[#07111e]/85 px-5 py-3 text-xs font-medium text-white opacity-0 shadow-2xl backdrop-blur-xl xl:flex"
              >
                <span className="relative flex size-2">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-[#b9ff66] opacity-70" />
                  <span className="relative inline-flex size-2 rounded-full bg-[#b9ff66]" />
                </span>
                Your AI command center is ready
              </div>

              {statuses.map(({ icon: Icon, text, className }) => (
                <div
                  data-dashboard-status
                  key={text}
                  className={`absolute ${className} hidden translate-y-10 scale-75 items-center gap-3 rounded-sm bg-black/75 px-5 py-3 text-sm font-medium text-white opacity-0 shadow-[0_20px_50px_rgba(4,18,77,.35)] backdrop-blur-md xl:flex`}
                >
                  <Icon size={18} className="text-[#b9ff66]" aria-hidden />
                  {text}
                </div>
              ))}
              <div
                data-dashboard-status
                className="absolute -bottom-6 left-[9%] hidden translate-y-10 scale-75 items-center gap-2 rounded-sm bg-black/70 px-4 py-3 text-xs text-white/85 opacity-0 backdrop-blur-md xl:flex"
              >
                <CheckCircle2 size={12} className="text-[#b9ff66]" aria-hidden />{" "}
                Website health: excellent
              </div>
            </div>
          </div>
        </div>

        <div
          data-scroll-hint
          className="absolute inset-x-0 bottom-5 z-20 hidden justify-center xl:flex"
        >
          <span className="rounded-full border border-white/25 bg-white/15 px-4 py-2 text-[9px] font-semibold uppercase tracking-[.18em] text-white/90 backdrop-blur-md">
            Scroll to open the dashboard
          </span>
        </div>
      </div>
    </section>
  );
}
